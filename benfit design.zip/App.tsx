import React from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import Layout from './components/Layout';
import Welcome from './screens/Welcome';
import Auth from './screens/Auth';
import Dashboard from './screens/Dashboard';
import WorkoutPlans from './screens/WorkoutPlans';
import ExerciseDetail from './screens/ExerciseDetail';
import Profile from './screens/Profile';

const App: React.FC = () => {
  return (
    <HashRouter>
      <Layout>
        <Routes>
          <Route path="/" element={<Welcome />} />
          <Route path="/auth" element={<Auth />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/plans" element={<WorkoutPlans />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/exercise/:id" element={<ExerciseDetail />} />
          {/* Fallback routes for demo nav items */}
          <Route path="/progress" element={<div className="p-8 text-center text-gray-500">Progress Screen Placeholder</div>} />
          <Route path="/community" element={<div className="p-8 text-center text-gray-500">Community Screen Placeholder</div>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Layout>
    </HashRouter>
  );
};

export default App;