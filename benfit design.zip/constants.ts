import { Exercise, WeeklyData, WorkoutPlan } from "./types";

export const WEEKLY_STATS: WeeklyData[] = [
  { day: 'D', percentage: 20 },
  { day: 'S', percentage: 60 },
  { day: 'T', percentage: 0 },
  { day: 'Q', percentage: 80 },
  { day: 'Q', percentage: 40 },
  { day: 'S', percentage: 95 },
  { day: 'S', percentage: 0 },
];

export const WORKOUT_PLANS: WorkoutPlan[] = [
  {
    id: '1',
    title: 'Força de Corpo Inteiro',
    duration: '45 min',
    level: 'Intermediário',
    location: 'Academia',
    category: 'Força',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBOfMpARnBPU6CuJKWdi14ted7sOgfzWKlV4UZzWx0mSoEsnhsy1lA61ABQ6C0pdoDk0ExZnqCCyZpz1Q_0u1nzYPAvoHa6EuX5nZyBQegRBlnVAEMLgQfH6TLyWy_85dgdpRo8Ea4Ey7K2URDRjnLUOfAsTqr_8cqXVR8MF3frqkdkb9J9kfSC9y7zBGGX2DG2t295uUpIScrSbf3yaxYLpvVCcIi6XcITqamd72ky-NMkcFFMYS5LMSSeUgQmKr3D9Ig0EjC5C0k'
  },
  {
    id: '2',
    title: 'Cardio para Resistência',
    duration: '30 min',
    level: 'Iniciante',
    location: 'Casa',
    category: 'Cardio',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDw_KtWaPOekvUNrDz3uxULFGZtegylSHVfYBJ1TDcyJCLQtUmRFu6IB4EjXqzAy31_AzmJz7hjUTTJCiKnzm695TKWk3J0LerC0eAEEQXpaT1hor0iVFMWZUos8IVqXv_kdTF7q8EbGnpNLFZjaP1Pm7xx0dyfCLb0tC3v4o1R1X5gYNGkVPMYfQTefAfozbKlv0WebOmW5sFtVlnN_nVqFL91dIfpiBqf-DjnQoVGxQV3xAA4tDAE6sdX2HkS_P1X1o7MYlliM8I'
  },
  {
    id: '3',
    title: 'Flexibilidade & Yoga',
    duration: '60 min',
    level: 'Todos',
    location: 'Casa',
    category: 'Yoga',
    imageUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCF0EgPiQitvUEz0IwotuW6iUaGBPmArNsM0hOtu7gmjlZDWLVgwLO3F3nymkHZ-DqCScH-tYlZjFK6EdHnJe3gtu9oR7RArT6pD68s94OP9qj-GVWrPcp4MFZ7rmvinf7AyOe9R7lmp_FbE7nPqScLFXCySpMo5LvSIJNtSgFW3qAbMQAV9DC28VbqV0hGOckOHQ3Se908sDNY1MChDXki4uigGMSBItN9sJDyywrbDZKflY9NjdG1WM_MmstfppD5W1mCsFdTl8o'
  }
];

export const EXERCISES: Record<string, Exercise> = {
  'supino': {
    id: 'supino',
    name: 'Supino Reto com Barra',
    equipment: 'Barra, Banco',
    difficulty: 'Intermediário',
    targetMuscle: 'Peitoral',
    videoUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAymJjoFkLgVN21LtXhF8w9JH0nFdtg48uWgGQewbBZd_liUBEHjHmOkfKoZSrnPW3Vq8tlZ1faoilSntJssJ3tFTUV6e80naJZWuRW6_KdXYwie_1n-upoyxAZl32AsfNYMbTw29etET12FVNxnaXI403E55yoidFs3rJButOMYTVY9QTFIDxk0RGHfzzsgQdTMqUJf2UR-1I_mFPH-pn4tS7BtkPxxy6dcUHy4E2jsMU7EFv_QGgcgjurazWAVSCB9rdmiAvyiF0',
    videoDuration: '1:00',
    steps: [
      { stepNumber: 1, description: 'Deite-se no banco com os pés firmemente apoiados no chão. Suas costas devem estar retas e seus ombros para trás e para baixo.' },
      { stepNumber: 2, description: 'Segure a barra com as mãos um pouco mais afastadas que a largura dos ombros. Retire a barra do suporte e posicione-a acima do seu peito com os braços estendidos.' },
      { stepNumber: 3, description: 'Inspire e abaixe a barra lentamente até tocar a parte central do seu peito. Mantenha os cotovelos em um ângulo de aproximadamente 45 graus em relação ao corpo.' },
      { stepNumber: 4, description: 'Expire e empurre a barra para cima de forma explosiva, retornando à posição inicial sem travar os cotovelos completamente. Repita o movimento.' },
    ]
  },
  'prancha': {
    id: 'prancha',
    name: 'Prancha',
    equipment: 'Corpo',
    difficulty: 'Médio',
    targetMuscle: 'Core',
    videoUrl: 'https://lh3.googleusercontent.com/aida-public/AB6AXuCBs4UtJODNqk-utNeBOt3I0EgjTiowcW56LVekd8jA2XvZ-6Vu2gRqD6AY7_gj_DLnE-YGEhrbDQn5D0pAsArXn_Ra9N9_mwjEU8acLpT_DYzX4dVSRIpyL-_Hv1J6Hrbv5KSKAUahzt7-bDorbAzaiSUUKADttvubq541ymMdOcVxBnYurMmr8eXawgZ7lcnKGJtpAq4v8WEC4kKFaFGhfDhUe6rqgdlHXAx2Q4x5cGMK9WJvYycsudX9QrMkBBtgGLA8OXFTns0',
    videoDuration: '1:00',
    steps: [
      { stepNumber: 1, description: 'Comece na posição de quatro, com os joelhos e mãos no chão. Coloque os antebraços no chão, com os cotovelos alinhados diretamente sob os ombros e as mãos em punho ou espalmadas.' },
      { stepNumber: 2, description: 'Estenda as pernas para trás, uma de cada vez, apoiando-se nos dedos dos pés. Seu corpo deve formar uma linha reta da cabeça aos calcanhares.' },
      { stepNumber: 3, description: 'Contraia o abdômen e os glúteos para manter a estabilidade. Evite arquear as costas ou levantar os quadris.' },
      { stepNumber: 4, description: 'Mantenha a posição pelo tempo desejado, respirando de forma controlada. Para finalizar, abaixe os joelhos suavemente até o chão.' },
    ],
    tips: [
      { title: 'Corpo Reto', description: 'Mantenha seu corpo em uma linha reta da cabeça aos calcanhares. Evite deixar o quadril cair ou levantar demais.', icon: 'straighten' },
      { title: 'Ative o Core', description: 'Contraia ativamente os músculos do abdômen e os glúteos durante todo o exercício.', icon: 'compress' },
      { title: 'Respire', description: 'Não prenda a respiração. Mantenha uma respiração constante e controlada.', icon: 'air' },
    ]
  }
};