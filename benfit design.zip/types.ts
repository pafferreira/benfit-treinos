export interface WorkoutPlan {
  id: string;
  title: string;
  duration: string;
  level: string;
  location: string;
  imageUrl: string;
  category: string;
}

export interface ExerciseStep {
  stepNumber: number;
  description: string;
}

export interface ExerciseTip {
  title: string;
  description: string;
  icon: string;
}

export interface Exercise {
  id: string;
  name: string;
  equipment: string;
  difficulty: string;
  targetMuscle: string;
  videoUrl: string; // Placeholder for video thumbnail
  videoDuration: string;
  steps: ExerciseStep[];
  tips?: ExerciseTip[];
}

export interface UserStats {
  weight: number;
  height: number;
  weightGoal: number;
  totalWorkouts: number;
}

export interface WeeklyData {
  day: string;
  percentage: number; // 0-100
}