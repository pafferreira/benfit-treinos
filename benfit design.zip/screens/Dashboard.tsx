import React from 'react';
import { WEEKLY_STATS } from '../constants';
import { useNavigate } from 'react-router-dom';

const Dashboard: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="flex flex-col w-full pb-24">
      {/* Top App Bar */}
      <div className="flex flex-col gap-2 p-4 pb-2">
        <div className="flex h-12 items-center justify-between">
          <div className="flex shrink-0 items-center">
            <div 
              className="aspect-square size-10 rounded-full bg-cover bg-center bg-no-repeat cursor-pointer"
              onClick={() => navigate('/profile')}
              style={{ backgroundImage: `url("https://lh3.googleusercontent.com/aida-public/AB6AXuDVjeWaWZsJRnTIPAfaekQXjZAf6X-DrU5ikNyzoDHLj0SLAPoKGfYQSgquizQ11k-cXEiMrfYBjXeIUjfCPUUlOy4Y1XMe4tzWddWayK--UEsJI_oFJUF9sORa7lDo2yuKlzrQxp3_UizBgRHF4Mdyb8p05ipbpF6mwToVTzf-X6c8IAYKrxRFABQgHP49kCMdYPmVgjDZQCCQVLuZok8LubZHyhPw1-I4s-5Omzs6SI1bk9dbdfqS0EvpHqTUo06djOfz839RgWA")` }}
            ></div>
          </div>
          <div className="flex w-12 items-center justify-end">
            <button className="flex h-12 cursor-pointer items-center justify-center gap-2 overflow-hidden rounded-lg bg-transparent p-0 text-white">
              <span className="material-symbols-outlined text-white/90">notifications</span>
            </button>
          </div>
        </div>
        <p className="text-[28px] font-bold leading-tight tracking-[-0.01em] text-gray-900 dark:text-white">
          Olá, Maria!
        </p>
      </div>

      {/* Weekly Summary */}
      <h2 className="px-4 pb-3 pt-5 text-[22px] font-bold leading-tight tracking-[-0.015em] text-gray-900 dark:text-white">
        Resumo Semanal
      </h2>

      <div className="px-4">
        <div className="flex flex-col gap-4 rounded-xl bg-white/5 p-4 dark:bg-surface-dark border border-gray-100 dark:border-transparent">
          <div className="flex min-w-72 flex-1 flex-col gap-2">
            <p className="text-base font-medium leading-normal text-gray-700 dark:text-gray-300">Treinos da Semana</p>
            <p className="text-[32px] font-bold leading-tight tracking-[-0.01em] text-gray-900 dark:text-white">4 Treinos</p>
            <div className="flex items-center gap-2">
              <p className="text-base font-normal leading-normal text-gray-500 dark:text-gray-400">Tempo Total: 3h 15m</p>
              <div className="flex items-center gap-0.5">
                <span className="material-symbols-outlined text-sm text-green-500">arrow_upward</span>
                <p className="text-base font-medium leading-normal text-green-500">+15%</p>
              </div>
            </div>
            
            {/* Custom Bar Chart Representation */}
            <div className="grid min-h-[140px] grid-flow-col items-end justify-items-center gap-4 pt-4">
              {WEEKLY_STATS.map((stat, index) => (
                <div key={index} className="flex h-full w-full flex-col items-center gap-2">
                  <div className="h-full w-4 rounded-full bg-gray-200 dark:bg-gray-800 relative overflow-hidden">
                    <div 
                      className="absolute bottom-0 w-full rounded-full bg-primary transition-all duration-500"
                      style={{ height: `${stat.percentage}%` }}
                    ></div>
                  </div>
                  <p className="text-[13px] font-bold leading-normal tracking-[0.015em] text-gray-500 dark:text-gray-400">
                    {stat.day}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="px-4 py-6">
        <button 
          onClick={() => navigate('/plans')}
          className="flex h-12 w-full cursor-pointer items-center justify-center gap-2 overflow-hidden rounded-xl bg-primary px-5 text-base font-bold leading-normal tracking-[0.015em] text-white hover:bg-blue-600 transition-colors"
        >
          <span className="material-symbols-outlined text-white">add_circle</span>
          <span className="truncate">Iniciar Novo Treino</span>
        </button>
      </div>

      {/* Recent Workouts */}
      <h3 className="px-4 pb-3 pt-2 text-lg font-bold leading-tight tracking-[-0.015em] text-gray-900 dark:text-white">
        Treinos Recentes
      </h3>
      <div className="flex flex-col gap-3 px-4">
        <div 
          onClick={() => navigate('/exercise/supino')}
          className="flex items-center gap-4 rounded-xl bg-white dark:bg-surface-dark p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-white/10 transition-colors"
        >
          <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary/20">
            <span className="material-symbols-outlined text-primary">fitness_center</span>
          </div>
          <div className="flex flex-1 flex-col">
            <p className="font-medium text-gray-900 dark:text-white">Treino de Peito e Tríceps</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">Ontem - 45 min</p>
          </div>
          <span className="material-symbols-outlined text-gray-500">chevron_right</span>
        </div>
        <div 
           onClick={() => navigate('/exercise/prancha')}
           className="flex items-center gap-4 rounded-xl bg-white dark:bg-surface-dark p-3 cursor-pointer hover:bg-gray-50 dark:hover:bg-white/10 transition-colors"
        >
          <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary/20">
            <span className="material-symbols-outlined text-primary">sprint</span>
          </div>
          <div className="flex flex-1 flex-col">
            <p className="font-medium text-gray-900 dark:text-white">Cardio Intenso</p>
            <p className="text-sm text-gray-500 dark:text-gray-400">15 de Abr - 30 min</p>
          </div>
          <span className="material-symbols-outlined text-gray-500">chevron_right</span>
        </div>
      </div>

      {/* Goals */}
      <h3 className="px-4 pb-3 pt-6 text-lg font-bold leading-tight tracking-[-0.015em] text-gray-900 dark:text-white">
        Metas de Fitness
      </h3>
      <div className="flex flex-col gap-4 px-4">
        <div className="rounded-xl bg-white dark:bg-surface-dark p-4">
          <div className="flex items-center justify-between">
            <p className="font-medium text-gray-900 dark:text-white">Correr 10km na semana</p>
            <p className="font-medium text-primary">8.5 / 10 km</p>
          </div>
          <div className="mt-2 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-700 overflow-hidden">
            <div className="h-2 rounded-full bg-primary" style={{ width: '85%' }}></div>
          </div>
        </div>
        <div className="rounded-xl bg-white dark:bg-surface-dark p-4">
          <div className="flex items-center justify-between">
            <p className="font-medium text-gray-900 dark:text-white">Perder 2kg no mês</p>
            <p className="font-medium text-primary">0.5 / 2 kg</p>
          </div>
          <div className="mt-2 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-700 overflow-hidden">
            <div className="h-2 rounded-full bg-primary" style={{ width: '25%' }}></div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;