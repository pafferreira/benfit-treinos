import React from 'react';
import { useNavigate } from 'react-router-dom';

const Welcome: React.FC = () => {
  const navigate = useNavigate();

  return (
    <div className="relative flex h-screen w-full flex-col font-display overflow-hidden">
      <div 
        className="w-full h-full bg-center bg-no-repeat bg-cover flex flex-col justify-end"
        style={{
          backgroundImage: `linear-gradient(rgba(16, 22, 34, 0.6), rgba(16, 22, 34, 1)), url("https://lh3.googleusercontent.com/aida-public/AB6AXuDFRYV9JIfIqoPbx9Pbkzli2bUD83fsSK5zcYr-opynpQN_xlYpKtI14YnbVdSR7AuZmNgWmuHUynEgoZyueCGJNjSVmRINq9oSqdRKzJW_Qx2m1szaTDwOQqcPO69lh1GgYdt2S84wmoNRpJTOJWe1NmMJGVRjGZKKSit6iUbP5Z6H4H8TnGv3PzM6fvu_ATELVqutMpGL2YOhsIVq-R9HRJSQ1556PKQXPW_C6-tA73fpGD01laJLUhSEBywFDF5hFKjtMYpaYac")`
        }}
      >
        <div className="flex-grow flex flex-col justify-center items-center px-4 pt-16 mt-20">
          <div className="flex justify-center mb-8">
            <span className="material-symbols-outlined text-white text-7xl">fitness_center</span>
          </div>
          <h1 className="text-white tracking-tight text-4xl font-bold leading-tight px-4 text-center pb-4 pt-6">
            Transforme o seu Treino
          </h1>
          <p className="text-gray-300 text-base font-normal leading-relaxed pb-3 pt-1 px-4 text-center max-w-sm">
            Planos personalizados e acompanhamento de progresso para atingir os seus objetivos.
          </p>
        </div>

        <div className="flex flex-col items-center px-4 pb-12 pt-8 mb-8">
          <div className="flex w-full max-w-sm px-4 py-3">
            <button 
              onClick={() => navigate('/auth')}
              className="flex w-full cursor-pointer items-center justify-center overflow-hidden rounded-xl h-14 px-5 bg-primary hover:bg-blue-600 transition-colors text-white text-lg font-bold leading-normal tracking-[0.015em]"
            >
              Começar
            </button>
          </div>
          <div className="flex justify-center pt-3">
            <p className="text-gray-400 text-sm font-normal">
              Já tem uma conta? <button onClick={() => navigate('/auth')} className="font-bold text-white hover:underline">Iniciar sessão</button>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Welcome;