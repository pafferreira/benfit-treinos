import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { EXERCISES } from '../constants';

const ExerciseDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const exercise = id ? EXERCISES[id] : null;
  const [activeTab, setActiveTab] = useState<'Instruções' | 'Dicas' | 'Músculos'>('Instruções');

  if (!exercise) {
    return <div className="text-center p-10 text-white">Exercício não encontrado</div>;
  }

  const hasTips = exercise.tips && exercise.tips.length > 0;
  const secondTabLabel = hasTips ? 'Dicas' : 'Músculos';

  return (
    <div className="relative flex h-auto min-h-screen w-full flex-col font-display bg-background-light dark:bg-background-dark pb-24">
      {/* Top Bar */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-20">
        <div className="text-slate-800 dark:text-white flex size-12 shrink-0 items-center justify-start -ml-2">
          <button onClick={() => navigate(-1)} className="material-symbols-outlined text-2xl p-2 rounded-full hover:bg-gray-200 dark:hover:bg-white/10 transition-colors">arrow_back_ios_new</button>
        </div>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center truncate px-2">{exercise.name}</h2>
        <div className="flex size-12 shrink-0 items-center"></div>
      </div>

      <div className="flex-1">
        {/* Video Player Placeholder */}
        <div className="px-4 pt-2">
          <div 
            className="relative flex items-center justify-center bg-cover bg-center aspect-video rounded-xl p-4 overflow-hidden group cursor-pointer"
            style={{ backgroundImage: `url("${exercise.videoUrl}")` }}
          >
            <div className="absolute inset-0 bg-black/30 group-hover:bg-black/40 transition-all"></div>
            <button className="relative flex shrink-0 items-center justify-center rounded-full size-16 bg-black/40 text-white backdrop-blur-sm group-hover:scale-110 transition-transform">
              <span className="material-symbols-outlined fill text-4xl">play_arrow</span>
            </button>
            <div className="absolute inset-x-0 bottom-0 px-4 py-3">
              <div className="flex h-4 items-center justify-center gap-1">
                <div className="h-1 flex-1 rounded-full bg-white/90" style={{ flexBasis: '25%' }}></div>
                <div className="relative"><div className="absolute -left-1.5 -top-1.5 size-3 rounded-full bg-white"></div></div>
                <div className="h-1 flex-1 rounded-full bg-white/40" style={{ flexBasis: '75%' }}></div>
              </div>
              <div className="flex items-center justify-between mt-1">
                <p className="text-white text-xs font-medium tracking-[0.015em]">0:15</p>
                <p className="text-white text-xs font-medium tracking-[0.015em]">{exercise.videoDuration}</p>
              </div>
            </div>
          </div>
        </div>

        {/* Info Grid */}
        <div className="grid grid-cols-[repeat(auto-fit,minmax(150px,1fr))] gap-3 p-4">
          <div className="flex flex-1 gap-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-dark p-4 flex-col">
            <div className="text-primary">
              <span className="material-symbols-outlined">
                {exercise.equipment === 'Corpo' ? 'accessibility_new' : 'fitness_center'}
              </span>
            </div>
            <div className="flex flex-col gap-1">
              <h2 className="text-slate-900 dark:text-white text-base font-bold leading-tight">Equipamento</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal">{exercise.equipment}</p>
            </div>
          </div>
          <div className="flex flex-1 gap-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-dark p-4 flex-col">
            <div className="text-primary">
              <span className="material-symbols-outlined">signal_cellular_alt</span>
            </div>
            <div className="flex flex-col gap-1">
              <h2 className="text-slate-900 dark:text-white text-base font-bold leading-tight">Dificuldade</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal">{exercise.difficulty}</p>
            </div>
          </div>
          <div className="flex flex-1 gap-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-surface-dark p-4 flex-col col-span-full sm:col-span-1">
            <div className="text-primary">
              <span className="material-symbols-outlined">body_system</span>
            </div>
            <div className="flex flex-col gap-1">
              <h2 className="text-slate-900 dark:text-white text-base font-bold leading-tight">Músculo Alvo</h2>
              <p className="text-slate-500 dark:text-slate-400 text-sm font-normal leading-normal">{exercise.targetMuscle}</p>
            </div>
          </div>
        </div>

        {/* Tab Switcher */}
        <div className="flex px-4 py-3">
          <div className="flex h-12 flex-1 items-center justify-center rounded-xl bg-slate-200 dark:bg-slate-800 p-1">
            <button 
              onClick={() => setActiveTab('Instruções')}
              className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-sm font-medium leading-normal transition-all duration-200 ${activeTab === 'Instruções' ? 'bg-white dark:bg-background-dark shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400'}`}
            >
              Instruções
            </button>
            <button 
              onClick={() => setActiveTab(secondTabLabel)}
              className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-sm font-medium leading-normal transition-all duration-200 ${activeTab === secondTabLabel ? 'bg-white dark:bg-background-dark shadow-sm text-slate-900 dark:text-white' : 'text-slate-500 dark:text-slate-400'}`}
            >
              {secondTabLabel}
            </button>
          </div>
        </div>

        {/* Content */}
        {activeTab === 'Instruções' ? (
          <div>
            <h3 className="text-slate-900 dark:text-white tracking-light text-2xl font-bold leading-tight px-4 text-left pb-2 pt-2">Passo a passo</h3>
            <ul className="flex flex-col gap-4 p-4">
              {exercise.steps.map((step) => (
                <li key={step.stepNumber} className="flex items-start gap-4">
                  <div className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary font-bold">
                    {step.stepNumber}
                  </div>
                  <p className="flex-1 text-slate-600 dark:text-slate-300 text-base leading-relaxed">
                    {step.description}
                  </p>
                </li>
              ))}
            </ul>
          </div>
        ) : (
          <div>
            {hasTips ? (
               <div className="flex flex-col gap-4 p-4">
                 <h3 className="text-slate-900 dark:text-white tracking-light text-2xl font-bold leading-tight px-0 text-left pb-2 pt-2">Dicas</h3>
                 {exercise.tips?.map((tip, idx) => (
                   <div key={idx} className="flex items-start gap-4">
                     <div className="flex size-8 shrink-0 items-center justify-center rounded-full bg-primary/10 text-primary">
                       <span className="material-symbols-outlined text-xl">{tip.icon}</span>
                     </div>
                     <div className="flex-1">
                       <h4 className="text-slate-800 dark:text-slate-100 font-bold text-base leading-tight">{tip.title}</h4>
                       <p className="text-slate-600 dark:text-slate-300 text-base leading-relaxed mt-1">{tip.description}</p>
                     </div>
                   </div>
                 ))}
               </div>
            ) : (
              <div className="p-4 text-center text-slate-500 dark:text-slate-400">
                Informações musculares detalhadas em breve.
              </div>
            )}
          </div>
        )}
      </div>

      {/* Sticky Footer CTA */}
      <footer className="fixed bottom-0 left-0 right-0 z-10 bg-gradient-to-t from-background-light/100 via-background-light/95 to-background-light/0 dark:from-background-dark/100 dark:via-background-dark/95 dark:to-background-dark/0 p-4 pt-6">
        <button className="w-full h-14 bg-primary text-white rounded-xl font-bold text-base flex items-center justify-center gap-2 shadow-lg shadow-primary/30 hover:bg-blue-600 transition-colors">
          <span className="material-symbols-outlined">add</span>
          Adicionar ao Treino
        </button>
      </footer>
    </div>
  );
};

export default ExerciseDetail;