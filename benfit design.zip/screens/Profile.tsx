import React from 'react';

const Profile: React.FC = () => {
  return (
    <div className="flex flex-col w-full pb-24 font-display">
      {/* Top Header */}
      <div className="flex items-center p-4 pb-2 bg-background-light dark:bg-background-dark sticky top-0 z-20">
        <button className="flex items-center justify-center text-slate-800 dark:text-white size-12 shrink-0 rounded-full hover:bg-gray-200 dark:hover:bg-white/10 transition-colors">
          <span className="material-symbols-outlined text-2xl">settings</span>
        </button>
        <h2 className="flex-1 text-center text-lg font-bold leading-tight tracking-[-0.015em] text-slate-900 dark:text-white">Perfil</h2>
        <button className="flex items-center justify-center text-slate-800 dark:text-white size-12 shrink-0 rounded-full hover:bg-gray-200 dark:hover:bg-white/10 transition-colors">
          <span className="material-symbols-outlined text-2xl">edit</span>
        </button>
      </div>

      {/* Profile Header */}
      <div className="flex p-4 flex-col items-center gap-4">
        <div className="aspect-square w-32 min-h-[8rem] rounded-full bg-cover bg-center bg-no-repeat shadow-lg ring-4 ring-white/5" 
             style={{ backgroundImage: `url("https://lh3.googleusercontent.com/aida-public/AB6AXuBM-2j88LzmGYV7Jml0x8jW8lOI_SHQ3yILyM48CB4bEJN0KPVCRjEYHzM5uhf56AXPiZy51xVMRBUzJ047nM-6jx_BonddElZvODmOnwHuJbQr1Lz02l02ujkOJOp1veWWTEOASxLQeZKzITWJI1KdLIhGh0gakAviD41OEcmOJbeETAhs1rh1wFgpXoN5tMiR4b0MPerClWyjOCny4y67t9bTcpAkG4UqnnUq1FIClaSdcPxzKh9UJ3qHIBwbB4CXKZttyB8CFfU")` }}>
        </div>
        <div className="flex flex-col items-center justify-center">
          <p className="text-[22px] font-bold leading-tight tracking-[-0.015em] text-slate-900 dark:text-white text-center">Maria Silva</p>
          <p className="text-base font-normal leading-normal text-slate-500 dark:text-slate-400 text-center">Membro desde Janeiro 2023</p>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 p-4">
        <div className="flex flex-1 flex-col gap-2 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <p className="text-base font-medium leading-normal text-slate-600 dark:text-slate-400">Peso</p>
          <p className="text-2xl font-bold leading-tight tracking-tight text-slate-900 dark:text-white">70 kg</p>
        </div>
        <div className="flex flex-1 flex-col gap-2 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <p className="text-base font-medium leading-normal text-slate-600 dark:text-slate-400">Altura</p>
          <p className="text-2xl font-bold leading-tight tracking-tight text-slate-900 dark:text-white">165 cm</p>
        </div>
        <div className="flex flex-1 flex-col gap-2 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <p className="text-base font-medium leading-normal text-slate-600 dark:text-slate-400">Meta de Peso</p>
          <p className="text-2xl font-bold leading-tight tracking-tight text-slate-900 dark:text-white">60 kg</p>
        </div>
        <div className="flex flex-1 flex-col gap-2 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <p className="text-base font-medium leading-normal text-slate-600 dark:text-slate-400">Treinos</p>
          <p className="text-2xl font-bold leading-tight tracking-tight text-slate-900 dark:text-white">128</p>
        </div>
      </div>

      {/* Goals */}
      <h3 className="text-lg font-bold leading-tight tracking-[-0.015em] text-slate-900 dark:text-white px-4 pb-2 pt-4">As Minhas Metas</h3>
      <div className="flex flex-col gap-4 p-4 pt-2">
        <div className="flex flex-col gap-3 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between gap-6">
            <p className="text-base font-medium leading-normal text-slate-900 dark:text-white">Perder 5kg</p>
            <p className="text-sm font-normal leading-normal text-slate-500 dark:text-slate-400">3/5 kg</p>
          </div>
          <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
            <div className="h-2 rounded-full bg-primary" style={{ width: '60%' }}></div>
          </div>
        </div>
        <div className="flex flex-col gap-3 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex items-center justify-between gap-6">
            <p className="text-base font-medium leading-normal text-slate-900 dark:text-white">Treinar 3x por semana</p>
            <p className="text-sm font-normal leading-normal text-slate-500 dark:text-slate-400">2/3 treinos</p>
          </div>
          <div className="h-2 rounded-full bg-slate-200 dark:bg-slate-700 overflow-hidden">
            <div className="h-2 rounded-full bg-primary" style={{ width: '66.67%' }}></div>
          </div>
        </div>
      </div>

      {/* History */}
      <div className="flex items-center justify-between px-4 pb-2 pt-4">
        <h3 className="text-lg font-bold leading-tight tracking-[-0.015em] text-slate-900 dark:text-white">Histórico de Treinos</h3>
        <button className="text-sm font-semibold text-primary hover:text-blue-400">Ver Tudo</button>
      </div>
      
      <div className="flex flex-col gap-3 p-4 pt-2">
        <div className="flex items-center gap-4 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
            <span className="material-symbols-outlined text-primary text-2xl">fitness_center</span>
          </div>
          <div className="flex-1">
            <p className="font-semibold text-slate-900 dark:text-white">Treino de Peito e Tríceps</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Hoje, 45 min</p>
          </div>
          <span className="material-symbols-outlined text-slate-400 dark:text-slate-500">chevron_right</span>
        </div>
        <div className="flex items-center gap-4 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
            <span className="material-symbols-outlined text-primary text-2xl">directions_run</span>
          </div>
          <div className="flex-1">
            <p className="font-semibold text-slate-900 dark:text-white">Corrida na Esteira</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">Ontem, 30 min</p>
          </div>
          <span className="material-symbols-outlined text-slate-400 dark:text-slate-500">chevron_right</span>
        </div>
        <div className="flex items-center gap-4 rounded-xl bg-white dark:bg-surface-dark p-4 border border-slate-200 dark:border-slate-800">
          <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/20">
            <span className="material-symbols-outlined text-primary text-2xl">weight</span>
          </div>
          <div className="flex-1">
            <p className="font-semibold text-slate-900 dark:text-white">Treino de Perna</p>
            <p className="text-sm text-slate-500 dark:text-slate-400">2 dias atrás, 60 min</p>
          </div>
          <span className="material-symbols-outlined text-slate-400 dark:text-slate-500">chevron_right</span>
        </div>
      </div>
    </div>
  );
};

export default Profile;