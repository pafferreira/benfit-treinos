import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

const Auth: React.FC = () => {
  const navigate = useNavigate();
  const [mode, setMode] = useState<'login' | 'register'>('register');

  return (
    <div className="flex flex-col items-center justify-center p-4 min-h-screen bg-background-light dark:bg-background-dark font-display">
      <div className="w-full max-w-md mx-auto">
        <div className="flex justify-center mb-6">
          <span className="material-symbols-outlined text-primary text-6xl">fitness_center</span>
        </div>
        
        <h1 className="text-slate-900 dark:text-white tracking-tight text-[32px] font-bold leading-tight px-4 text-center pb-3 pt-6">
          Comece sua jornada fitness
        </h1>

        {/* Toggle */}
        <div className="px-4 py-3">
          <div className="flex h-12 flex-1 items-center justify-center rounded-xl bg-slate-200 dark:bg-slate-800 p-1">
            <button 
              onClick={() => setMode('login')}
              className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-sm font-medium leading-normal transition-all ${
                mode === 'login' 
                  ? 'bg-white dark:bg-background-dark shadow-sm text-slate-900 dark:text-white' 
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              Entrar
            </button>
            <button 
              onClick={() => setMode('register')}
              className={`flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-sm font-medium leading-normal transition-all ${
                mode === 'register' 
                  ? 'bg-white dark:bg-background-dark shadow-sm text-slate-900 dark:text-white' 
                  : 'text-slate-500 dark:text-slate-400'
              }`}
            >
              Registrar
            </button>
          </div>
        </div>

        {/* Form Fields */}
        <div className="flex flex-col gap-4 px-4 py-3">
          <label className="flex flex-col flex-1">
            <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Email</p>
            <input 
              type="email"
              className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 text-base font-normal leading-normal" 
              placeholder="seuemail@dominio.com" 
            />
          </label>

          <label className="flex flex-col flex-1">
            <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Senha</p>
            <div className="flex w-full flex-1 items-stretch">
              <input 
                type="password"
                className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-l-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border-y border-l border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 pr-2 text-base font-normal leading-normal" 
                placeholder="Crie uma senha forte" 
              />
              <div className="text-slate-400 dark:text-slate-500 flex border-y border-r border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 items-center justify-center pr-4 rounded-r-lg">
                <span className="material-symbols-outlined cursor-pointer">visibility</span>
              </div>
            </div>
          </label>

          {mode === 'register' && (
            <label className="flex flex-col flex-1">
              <p className="text-slate-900 dark:text-white text-base font-medium leading-normal pb-2">Confirmar Senha</p>
              <div className="flex w-full flex-1 items-stretch">
                <input 
                  type="password"
                  className="flex w-full min-w-0 flex-1 resize-none overflow-hidden rounded-l-lg text-slate-900 dark:text-white focus:outline-0 focus:ring-2 focus:ring-primary/50 border-y border-l border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 h-14 placeholder:text-slate-400 dark:placeholder:text-slate-500 p-4 pr-2 text-base font-normal leading-normal" 
                  placeholder="Confirme sua senha" 
                />
                <div className="text-slate-400 dark:text-slate-500 flex border-y border-r border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 items-center justify-center pr-4 rounded-r-lg">
                  <span className="material-symbols-outlined cursor-pointer">visibility_off</span>
                </div>
              </div>
            </label>
          )}
        </div>

        <div className="px-4 py-4">
          <button 
            onClick={() => navigate('/dashboard')}
            className="flex w-full items-center justify-center rounded-xl bg-primary hover:bg-blue-600 transition-colors h-14 text-white text-base font-bold leading-normal"
          >
            {mode === 'login' ? 'Entrar' : 'Criar Conta'}
          </button>
        </div>

        <p className="text-slate-500 dark:text-slate-400 text-xs font-normal leading-normal pb-3 pt-1 px-4 text-center">
          Ao {mode === 'login' ? 'entrar' : 'criar uma conta'}, você concorda com nossos <a className="underline text-primary" href="#">Termos de Serviço</a> e <a className="underline text-primary" href="#">Política de Privacidade</a>.
        </p>

        <div className="flex items-center gap-4 px-4 py-4">
          <div className="h-px flex-1 bg-slate-200 dark:bg-slate-700"></div>
          <p className="text-slate-500 dark:text-slate-400 text-sm font-medium">OU</p>
          <div className="h-px flex-1 bg-slate-200 dark:bg-slate-700"></div>
        </div>

        <div className="flex flex-col gap-4 px-4 py-2">
          <button className="flex w-full items-center justify-center gap-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-white dark:bg-slate-800 h-14 text-slate-900 dark:text-white text-base font-medium">
            <img src="https://lh3.googleusercontent.com/aida-public/AB6AXuAuDXbzmSOGEkpmCQJs_vUJ60xeb16Ncm88mnVbZPkTCzdPlPmHwClZC37X6mhHSP_-Hi6ncWWHXeJtF3V4gihL0e11ZZnsRzjQFQv04hWfrA7wpFowIAHCMkpbwq17qpW9bCK0EqGyLkxIEhAuuI4cvPw8FGQrcnjUb1QMbHAUEOAT7a3twt7z6JhMlJATVimqH-Iq3H-NvmdH_0wakkEea-dQCQXKj66uPCGXZmFaZaERlrg2Pad0V3wCHVyHgZMxyFduUs-FKLg" alt="Google logo" className="h-6 w-6" />
            <span>Continuar com Google</span>
          </button>
          <button className="flex w-full items-center justify-center gap-3 rounded-xl border border-slate-300 dark:border-slate-700 bg-black h-14 text-white text-base font-medium">
            <svg viewBox="0 0 24 24" fill="currentColor" className="h-6 w-6">
              <path d="M13.15,16.1c-0.01-0.05-0.02-0.1-0.02-0.16c0-0.05,0.01-0.1,0.02-0.15c0.33-0.91,0.56-1.92,0.56-3.01 c0-2.43-0.96-4.28-2.61-4.28c-1.74,0-2.83,1.55-2.83,3.77c0,2.9,1.52,4.83,3.13,4.83c0.46,0,0.95-0.19,1.4-0.56 C13.06,16.51,13.1,16.32,13.15,16.1z M15.5,3.22c-0.08-0.6-0.34-1.15-0.78-1.6c-0.58-0.58-1.35-0.87-2.31-0.87 c-0.88,0-1.85,0.39-2.81,1.15c-0.95,0.76-1.63,1.82-2.02,3.13c-0.82,2.73-0.2,5.65,1.51,7.45c0.55,0.58,1.21,1.03,1.95,1.34 c0.75,0.3,1.52,0.46,2.3,0.46c0.88,0,1.69-0.22,2.41-0.64c0.1-0.06,0.19-0.12,0.29-0.19c-1.32-0.95-2.03-2.39-2.03-4.04 c0-1.02,0.26-1.91,0.76-2.66c0.05-0.08,0.11-0.15,0.17-0.22C16.3,9.21,17.5,6.1,15.5,3.22z"></path>
            </svg>
            <span>Continuar com Apple</span>
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;