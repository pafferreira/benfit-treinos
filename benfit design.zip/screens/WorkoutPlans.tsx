import React from 'react';
import { WORKOUT_PLANS } from '../constants';

const WorkoutPlans: React.FC = () => {
  const chips = ['Iniciante', 'Força', 'Cardio', '3 dias/semana', 'Academia'];

  return (
    <div className="flex flex-col w-full pb-24 font-display">
      {/* Top Header */}
      <div className="flex items-center bg-background-light dark:bg-background-dark p-4 pb-2 justify-between sticky top-0 z-20">
        <div className="text-slate-800 dark:text-white flex size-12 shrink-0 items-center">
          <span className="material-symbols-outlined cursor-pointer">arrow_back_ios_new</span>
        </div>
        <h2 className="text-slate-900 dark:text-white text-lg font-bold leading-tight tracking-[-0.015em] flex-1 text-center">Planos de Treino</h2>
        <div className="flex size-12 shrink-0 items-center"></div>
      </div>

      {/* Segmented Control */}
      <div className="flex px-4 py-3">
        <div className="flex h-10 flex-1 items-center justify-center rounded-lg bg-slate-200 dark:bg-[#1C2431] p-1">
          <label className="flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 bg-background-light dark:bg-background-dark shadow-sm text-slate-900 dark:text-white text-sm font-medium leading-normal">
            <span className="truncate">Featured Plans</span>
            <input type="radio" name="plan-type" value="Featured Plans" className="invisible w-0" defaultChecked />
          </label>
          <label className="flex cursor-pointer h-full grow items-center justify-center overflow-hidden rounded-lg px-2 text-slate-500 dark:text-slate-400 text-sm font-medium leading-normal">
            <span className="truncate">My Plans</span>
            <input type="radio" name="plan-type" value="My Plans" className="invisible w-0" />
          </label>
        </div>
      </div>

      {/* Search */}
      <div className="px-4 py-3">
        <label className="flex flex-col h-12 w-full">
          <div className="flex w-full flex-1 items-stretch rounded-lg h-full overflow-hidden">
            <div className="text-slate-400 dark:text-slate-400 flex border-none bg-slate-200 dark:bg-[#1C2431] items-center justify-center pl-4 pr-2">
              <span className="material-symbols-outlined">search</span>
            </div>
            <input 
              className="flex w-full min-w-0 flex-1 resize-none overflow-hidden text-slate-900 dark:text-white focus:outline-0 focus:ring-0 border-none bg-slate-200 dark:bg-[#1C2431] h-full placeholder:text-slate-500 dark:placeholder:text-slate-400 px-2 text-base font-normal leading-normal" 
              placeholder="Encontre um plano específico" 
            />
          </div>
        </label>
      </div>

      {/* Filter Chips */}
      <div className="flex gap-3 px-4 py-3 overflow-x-auto whitespace-nowrap hide-scrollbar">
        {chips.map((chip, index) => (
          <div 
            key={index} 
            className={`flex h-8 shrink-0 cursor-pointer items-center justify-center gap-x-2 rounded-lg pl-4 pr-4 transition-colors ${index === 0 ? 'bg-primary text-white' : 'bg-slate-200 dark:bg-[#1C2431] text-slate-800 dark:text-slate-300'}`}
          >
            <p className="text-sm font-medium leading-normal">{chip}</p>
          </div>
        ))}
      </div>

      {/* Plan Cards */}
      <div className="flex flex-col gap-4 px-4 pb-4">
        {WORKOUT_PLANS.map((plan) => (
          <div 
            key={plan.id}
            className="bg-cover bg-center flex flex-col items-stretch justify-end rounded-xl pt-[132px] overflow-hidden relative"
            style={{ 
              backgroundImage: `linear-gradient(0deg, rgba(0, 0, 0, 0.6) 0%, rgba(0, 0, 0, 0) 100%), url("${plan.imageUrl}")` 
            }}
          >
            <div className="flex w-full items-end justify-between gap-4 p-4 z-10">
              <div className="flex max-w-[440px] flex-1 flex-col gap-1">
                <p className="text-white tracking-light text-2xl font-bold leading-tight drop-shadow-md">{plan.title}</p>
                <p className="text-slate-200 text-base font-medium leading-normal drop-shadow-sm">{plan.duration} | {plan.level} | {plan.location}</p>
              </div>
              <button className="flex min-w-[84px] cursor-pointer items-center justify-center overflow-hidden rounded-lg h-10 px-4 bg-primary text-white text-sm font-bold leading-normal tracking-[0.015em] hover:bg-blue-600 transition-colors">
                <span className="truncate">Ver Plano</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* FAB */}
      <div className="fixed bottom-24 right-6 z-30">
        <button className="flex h-14 w-14 cursor-pointer items-center justify-center overflow-hidden rounded-full bg-primary text-white shadow-lg hover:bg-blue-600 transition-colors">
          <span className="material-symbols-outlined !text-3xl">add</span>
        </button>
      </div>
    </div>
  );
};

export default WorkoutPlans;