import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const BottomNav: React.FC = () => {
  const navigate = useNavigate();
  const location = useLocation();

  const isActive = (path: string) => location.pathname === path;

  const navItems = [
    { path: '/dashboard', label: 'Dashboard', icon: 'dashboard' },
    { path: '/plans', label: 'Treinos', icon: 'exercise' },
    { path: '/progress', label: 'Progresso', icon: 'leaderboard' },
    { path: '/profile', label: 'Perfil', icon: 'person' }, // Changed from community group icon to person based on typical flow, though screenshots showed "Comunidade" and "Perfil" separate. I will align with screenshots if possible, but the screenshots show "Comunidade" in dashboard view and "Perfil" view separately. I will assume Profile is the 4th tab for functionality or a separate screen. Let's make it match the dashboard screenshot "Comunidade" but link the "Avatar" to profile. 
    // Wait, the Dashboard screenshot shows "Comunidade" as 4th tab. The Profile screenshot shows a "Perfil" active tab at the bottom. 
    // This implies dynamic bottom nav or just different states. I will implement the 4 items from Dashboard and swap Community for Profile if we are on Profile to mimic the state, or just have 4 items: Dashboard, Treinos, Progresso, Perfil (Common pattern).
    // Let's stick to Dashboard screenshot: Dashboard, Treinos, Progresso, Comunidade. 
    // And Profile is accessed via Avatar in Top Bar.
  ];
  
  // Actually, looking at the Profile screenshot, the bottom nav HAS "Perfil" as the active tab (3rd item? No, looks like 4 items, Perfil is the 3rd or 4th?).
  // Let's standardise: Dashboard, Plans, Progress, Profile.
  
  const actualNavItems = [
    { path: '/dashboard', label: 'Dashboard', icon: 'dashboard' },
    { path: '/plans', label: 'Treinos', icon: 'exercise' },
    { path: '/profile', label: 'Perfil', icon: 'person' },
    { path: '/community', label: 'Comunidade', icon: 'group' },
  ];

  return (
    <div className="fixed bottom-0 left-0 right-0 border-t border-gray-200/10 bg-background-dark/95 backdrop-blur-lg z-50 pb-safe">
      <div className="flex h-20 items-center justify-around px-4">
        {actualNavItems.map((item) => (
          <button
            key={item.path}
            onClick={() => navigate(item.path)}
            className={`flex flex-col items-center gap-1 ${
              isActive(item.path) ? 'text-primary' : 'text-gray-400'
            }`}
          >
            <span className={`material-symbols-outlined ${isActive(item.path) ? 'fill' : ''}`}>
              {item.icon}
            </span>
            <span className={`text-xs ${isActive(item.path) ? 'font-bold' : 'font-medium'}`}>
              {item.label}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};

export default BottomNav;