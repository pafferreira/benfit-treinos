import React from 'react';
import { useLocation } from 'react-router-dom';
import BottomNav from './BottomNav';

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const location = useLocation();
  const hideNavPaths = ['/', '/auth'];
  const isExerciseDetail = location.pathname.startsWith('/exercise/');
  const shouldShowNav = !hideNavPaths.includes(location.pathname) && !isExerciseDetail;

  return (
    <div className="min-h-screen bg-background-light dark:bg-background-dark text-slate-900 dark:text-white pb-safe">
      {children}
      {shouldShowNav && <BottomNav />}
    </div>
  );
};

export default Layout;